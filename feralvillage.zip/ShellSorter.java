package com.twod.feralvillage;

import java.util.Comparator;

public class ShellSorter<Type> extends Sorter<Type> {
/** 
 * Shell sort implementation based on the one found here:
 * http://www.augustana.ab.ca/~mohrj/courses/2004.winter/csc310/source/ShellSort.java.html
 * Note that the running time can be tuned by adjusting the size of the increment used
 * to pass over the array each time.  Currently this function uses Robert Cruse's suggestion
 * of increment = increment / 3 + 1.
 */
 
public void sort(Type[] array, int count, Comparator<Type> comparator) {
    int increment = count / 3 + 1;

    // Sort by insertion sort at diminishing increments.
    while ( increment > 1 ) {
        for ( int start = 0; start < increment; start++ ) {
            insertionSort(array, count, start, increment, comparator);
        }
        increment = increment / 3 + 1;
    } 
    
    // Do a final pass with an increment of 1.
    // (This has to be outside the previous loop because the formula above for calculating the
    // next increment will keep generating 1 repeatedly.)
    insertionSort(array, count, 0, 1, comparator );
 }

    
/**
  *  Insertion sort modified to sort elements at a
  *  fixed increment apart.
  *
  *  The code can be revised to eliminate the initial
  *  'if', but I found that it made the sort slower.
  *
  *  @param start      the start position 
  *  @param increment  the increment
  */
public void insertionSort(Type[] array, int count, int start, int increment,
        Comparator<Type> comparator) {
    int j;
    int k;
    Type temp;

    for (int i = start + increment; i < count; i += increment) {
       j = i;
       k = j - increment;
       int delta = comparator.compare(array[j], array[k]);
       
       if ( delta < 0 ) {
          // Shift all previous entries down by the current
    	  // increment until the proper place is found.
          temp = array[j];
          do {
             array[j] = array[k];
             j = k;
             k = j - increment;
          } while ( j != start && comparator.compare(array[k], temp) > 0 );
          array[j] = temp;
       }
    }
  }
}